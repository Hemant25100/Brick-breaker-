import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
    private static final Map<String, String> users = new HashMap<>();

    static {
        users.put("user@example.com", "$2a$12$EIXw4KZ.xRZ.l4RVr5DwkuJ5KUnEjS0Mzoh1JtW8g2JULyldmTnW6"); // bcrypt hashed password for "password123"
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String email = sanitizeInput(request.getParameter("email"));
        String password = sanitizeInput(request.getParameter("password"));

        if (users.containsKey(email) && BCrypt.checkpw(password, users.get(email))) {
            request.setAttribute("email", email);
            request.getRequestDispatcher("profile.jsp").forward(request, response);
        } else {
            if (!users.containsKey(email)) {
                request.setAttribute("error", "Email not found");
            } else {
                request.setAttribute("error", "Incorrect password");
            }
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }

    private String sanitizeInput(String input) {
        return input == null ? "" : input.replaceAll("<", "&lt;").replaceAll(">", "&gt;").trim();
    }
}
