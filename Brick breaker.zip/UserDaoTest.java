import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mindrot.jbcrypt.BCrypt;

public class UserDaoTest {
    private UserDao userDao;

    @BeforeEach
    public void setup() {
        userDao = new UserDao();
        String hashedPassword = BCrypt.hashpw("password123", BCrypt.gensalt());
        userDao.addUser("user@example.com", hashedPassword);
    }

    @Test
    public void testUserExists() {
        assertTrue(userDao.userExists("user@example.com"));
    }

    @Test
    public void testUserDoesNotExist() {
        assertFalse(userDao.userExists("nonexistent@example.com"));
    }

    @Test
    public void testAddUser() {
        String hashedPassword = BCrypt.hashpw("newpassword123", BCrypt.gensalt());
        userDao.addUser("newuser@example.com", hashedPassword);
        assertTrue(userDao.userExists("newuser@example.com"));
    }
}
