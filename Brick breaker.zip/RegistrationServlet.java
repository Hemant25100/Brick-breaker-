import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/register")
public class RegistrationServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = sanitizeInput(request.getParameter("username"));
        String email = sanitizeInput(request.getParameter("email"));
        String password = sanitizeInput(request.getParameter("password"));

        if (username.isEmpty()) {
            request.setAttribute("error", "Username cannot be empty");
        } else if (email.isEmpty()) {
            request.setAttribute("error", "Email cannot be empty");
        } else if (password.length() < 8) {
            request.setAttribute("error", "Password must be at least 8 characters long");
        } else {
            String hashedPassword = BCrypt.hashpw(password, BCrypt.gensalt());
            request.setAttribute("username", username);
            request.setAttribute("email", email);
            request.getRequestDispatcher("profile.jsp").forward(request, response);
            return;
        }

        request.getRequestDispatcher("register.jsp").forward(request, response);
    }

    private String sanitizeInput(String input) {
        return input == null ? "" : input.replaceAll("<", "&lt;").replaceAll(">", "&gt;").trim();
    }
}
