import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mindrot.jbcrypt.BCrypt;

public class UserServiceTest {
    private UserService userService;

    @BeforeEach
    public void setup() {
        userService = new UserService();
        String hashedPassword = BCrypt.hashpw("password123", BCrypt.gensalt());
        userService.addUser("user@example.com", hashedPassword);
    }

    @Test
    public void testValidLogin() {
        assertTrue(userService.validateLogin("user@example.com", "password123"));
    }

    @Test
    public void testInvalidLogin() {
        assertFalse(userService.validateLogin("user@example.com", "wrongpassword"));
    }

    @Test
    public void testUserRegistration() {
        userService.registerUser("newuser@example.com", "newpassword123");
        assertTrue(userService.validateLogin("newuser@example.com", "newpassword123"));
    }
}
